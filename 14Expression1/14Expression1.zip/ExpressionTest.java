public class ExpressionTest {
    public static void main(String[] args) {
        Expression e = new Addition(new Numeral(3), new Numeral(4));
        System.out.println(e);
        System.out.println(e.evaluate());
    }
}
